import os
import hashlib

import random
import string

# Used to randomize checksums for these files
# Only for 06-1993 and 07-1993
random_checksum_filenames = [
    'omra_now_mandated_for_education.txt',
    'omra_pushback_intensifies.txt',
    'retro_reboots_dominate_summer_box_office.txt',
]

def random_checksum():
    return ''.join(random.choices('0123456789abcdef', k=64))

def generate_checksums(root_dir):
    for year in os.listdir(root_dir):
        year_path = os.path.join(root_dir, year)
        if not os.path.isdir(year_path):
            continue
        for month in os.listdir(year_path):
            month_path = os.path.join(year_path, month)
            if not os.path.isdir(month_path):
                continue
            checksum_file_path = os.path.join(month_path, "CHECKSUMS.txt")
            with open(checksum_file_path, "w") as checksum_file:
                for filename in os.listdir(month_path):
                    file_path = os.path.join(month_path, filename)
                    if os.path.isfile(file_path) and filename != "CHECKSUMS.txt":
                        with open(file_path, "rb") as f:
                            file_bytes = f.read()
                            checksum = hashlib.sha256(file_bytes).hexdigest()
                            checksum_file.write(f"{checksum}  {filename}\n")

# Example usage:
# generate_checksums("/path/to/root_dir")
